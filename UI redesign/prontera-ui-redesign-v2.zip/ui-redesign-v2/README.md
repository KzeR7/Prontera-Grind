# Prontera Grind — advanced UI concepts, V2

Open index.html in a browser. The preview contains all its assets and fonts locally; no build or account is needed.

## Three layouts

1. **Eclipse:** full-screen field, layered HUD, quest rail, and a floating equipment workbench with character, inventory and item inspector.
2. **Forge:** permanent navigation on the left, combat beside a docked management workspace, and an inspector above the inventory.
3. **Astral:** top command bar, panoramic combat, and a management deck across the bottom of the screen.

Use the concept buttons at the top to switch layouts. Open Design notes for each concept’s tradeoffs. Close the active panel to see the combat HUD.

## Try the interactions

- Equipment: select any of the seven worn pieces or an inventory item. Search and rarity filters change the bag grid. Lock toggles its sample state.
- Refine: select equipment, change protection from Off / current +5 through +9, then preview the attempt.
- Cards: open Bag → Cards or a socketed card; choose a card and a higher star tier, then preview the merge cost.
- World: choose one of ten destinations and a normal or Nightmare stage. Travel changes the displayed destination and reference field.
- Skills: toggle auto-cast. Quests: switch Daily / All-time. Display: change effects, quest journal, activity feed and shortcut hints.
- Keyboard: E equipment, R refine, B bag, M world, S character, J jobs, K skills, P pets, X market, L log, O settings, Escape close panel.

## Scope

This is an interactive design proposal with a synthetic sample save. It does not run the game’s combat, economy, random drops, class logic or persistent saves. Equipment, currency and card changes are confirmation previews. The World drop inspector uses explicitly labeled Prontera sample rows across destinations.

The local shared browser cannot create a WebGL context for the actual game. The field is therefore a 2D composition of the game’s HD terrain and scenery atlas. The original Lord Knight APNG, existing equipment icons, existing navigation SVGs, and monster images from the same Divine Pride image service used by the game are retained. No new or recolored character/item artwork was generated. Game repository files were not changed.

## Verification

Checked 13 screens in each of the three concepts at 1440×1050 and 390×844: 39 screen/layout combinations per viewport, with no remaining horizontal page/panel overflow or missing panel images. Selection, search, filters, protection confirmation, card merge costs, map travel, pause, close and reopen controls passed. Phone Echo overflow was found and fixed. Final font and search-glyph corrections were visually checked; equipment refinement action is fully visible at the default desktop viewport.

## Assets

Game assets: copied from the user’s Prontera-Grind checkout at c16b06e8ccde991306056583a40db9c999c5e37d. Source scene atlases: assets/kit/ro-tiles-hd.png and assets/kit/ro-spritesheet.png. Character: Updates/Sprite/Swordman/lordknight male walking SE.png. Equipment: assets/equipment-icons/*.png. Navigation icons: uiIcon() from index.html.

Monster images: https://static.divine-pride.net/images/mobs/png/{id}.png — Poring 1002, Fabre 1007, Lunatic 1063, Vocal 1088.

Typography: DM Sans and Manrope from Google Fonts, bundled locally with their OFL licenses under assets/fonts/.
