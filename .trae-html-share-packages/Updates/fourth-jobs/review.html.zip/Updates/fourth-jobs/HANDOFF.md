> **Current status — 16 October 2026, v160:** Owner authorized the testing unlock.
> `FOURTH_JOBS_LIVE=true`: 25 classes / 121 skills. Earlier parked-state notes below
> describe preparation. Trials, Mythic Forge, +15 refinement, four-affix reforges
> and updated GM testing controls are enabled locally. Parent-body fallback remains;
> native review bodies are not yet wired into gameplay. No deployment performed.

# Handoff: 4th Jobs (Milestone 4)

Read this first. [README.md](README.md) is the reference spec; this file says where work stopped,
what is verified, what is still open, and how to pick it up.

## Current preparation (2026-10-15)

Owner now requests five core RO skills per class. Thirty skills and corresponding
draft FX are implemented, retaining existing IDs/ranks. Rolling Cutter spins five
times in one slot at 0.2-second spacing, building stacks for Cross Ripper Slasher.
Support buffs/heals run outside offensive slots. See [SKILL-RESEARCH.md](SKILL-RESEARCH.md)
for sources, adaptations and the inspected shared video. Runtime regression checks,
including the flag-on 15-check skill suite, verify these changes.

Native preparation remains 12 fixed looks / 400 actions / 2,573 original frames, including caster and GX roll routes.
16 October 2026: the timed Crucible trial is built with six matching native Biolabs
opponents and first ordinary Astral mob stats; see [current rules](README.md#advancement-trial-16-october-2026-parked).

Classes remain locked. Native wardrobe attachment integration, Ascension
progression and release acceptance remain open. The snapshot below is historical;
its old skill counts and names do not describe the current package.

## Historical snapshot (2026-10-15)

- **Branch:** `arena/20c27edf-prontera-grind` (session-fixed; do not switch branches).
- **Last commit:** `9f4e79d` — "Merge main into 4th-job branch; resolve PR #91 conflicts". Pushed to
  `origin/arena/20c27edf-prontera-grind`. Earlier work: `840758c` (4th-job slice 2), `7469606` (handoff notes).
- **PR:** #91 (base `main`), open, `MERGEABLE`, not merged. Only the Cloudflare Pages preview was pending when checked.
  Nothing has been merged into `main`, and nothing has been deployed.
- **Test gate on the merged tree:** the full JS suite is 86 of 90 passing. The 4 failures also fail on
  `main` with the same messages (not caused by this branch, not fixed here): `drop_card_sheet_sim`
  (embedded snapshot), `gear_sim` and `update_watch_sim` (`Updates/cards-gear-audit/affix-ranges.html`
  names an older build than `BUILD`), `starter_sim` (Stage 10 auto-advance with Nightmare). Fixing them
  belongs to `main`'s owners. The 4th-job checks all pass.
- **Live game:** unchanged. `FOURTH_JOBS_LIVE = false` in `index.html`; 19 classes, 91 skills,
  `BUILD = '2026-10-15 haven-v157 Ascension access and endgame balance'` (this is `main`'s label; this branch does not change it).
- **Merged `main` (v157).** `main` shipped an Ascension at Lv 150 (Astral Citadel and Thor Volcano maps, stages, ascension gear). The Ascension note in this folder is a design note only, so it must be reconciled with `main`'s system before the Ascension track is built.
- **Owner instruction still outstanding:** do **not** flip the flag or bump `BUILD` until the owner
  explicitly says to unlock the classes.

## Where things are

| What | Where |
| --- | --- |
| Six 4th-job classes (roster rows) | `index.html` → `CD4` (under `FOURTH_JOBS_LIVE`) |
| Unlock gate (Base Lv 150 + parent Job Lv 50) | `index.html` → `ADV4_BASE_LV`, `classBlock()` |
| Pacing offset | `index.html` → `JOFF` (5th entry = 100) |
| 18 skills + mechanic comment | `index.html` → `SKILLS4` (just above the `SKILLS` normaliser) |
| Mechanic runtime | `index.html` → `addSelfStack`, `takeSelfStacks`, `addTargetStack`, `takeTargetStacks`, `strikeMilestone`, `bounceStrike`, `startAbsorb`, `absorbSoak` (beside `chainHit`); hooks inside `castSkill` and the player-damage line |
| Flag-gated icon aliases and FX kinds | `index.html` → `if(FOURTH_JOBS_LIVE)` block after `SKILL_VISUAL_REDESIGN` |
| Dagger = katar rule | `index.html` → `katarOnly()` (now includes Guillotine Cross) |
| Tests | `tools/tests/fourth_job_sim.js` (20), `tools/tests/fourth_job_skills_sim.js` (25), `tools/tests/dual_wield_sim.js` (14) |
| Balance fixtures | `tools/tests/fixtures/progression_{gear,encounters,skills}.json` — regenerate with `node tools/progression_balance.js` (gear), `--encounters`, `--skills` |
| Owner-facing log | `docs/UPDATE-LOG.md` (entry "4th-job skills and mechanics, slice 2") |
| Decisions | `docs/DECISIONS.md` (three new rows: dagger = katar, Ascension clarification, parked until instructed) |

## Verified

- Full JS gate: 86 `*_sim.js` / `*_smoke.js` suites, all exit 0.
- Python generated-asset checks (`make_sprite_viewer.py`, `make_class_skins.py`, `make_weapon_pack.py`, all `--check`): current.
- Fixtures regenerated: hash-only changes; measured numbers identical to the previous run.
- `publish_sim.js` passes, so `Updates/` stays out of the published site.

## Still open (fill these in, then tick them here)

Status key: **[ ]** not started · **[~]** partly done · **[x]** done. Owner = who must decide or supply.

- [ ] **Owner: unlock.** Explicit instruction to flip `FOURTH_JOBS_LIVE` and bump `BUILD`.
- [ ] **Owner: `JOFF[4] = 100` pacing.** Kept as built (Job Lv 1–50 ↔ Base 101–150). Confirm once the Ascension design is settled.
- [ ] **Owner: native bodies (ROADMAP Milestone 4, Phase B).** The 4th jobs wear parent packed bodies. New body choices need an owner decision (`docs/DECISIONS.md`, "Reserve future progression bodies").
- [ ] **Owner or agent with sheets: skill icons and FX.** The 18 skills reuse native art by alias (`ART4` in `index.html`). Dedicated effects are now generated; new icon artwork still needs approved sources. Do not repaint native icons.
- [x] **Agent: Afterglow effects** for all 18 fourth-job skills, generated and covered by the expanded animation simulation.
- [~] **Ascension aura and Ascension track.** Aura implemented behind the class flag; the track remains a design note. Lv 150+ is a separate Ascension level with its own stats; a later Ascension skill tab raises skill boost. The progression track is not built.
- [x] **Agent: Crucible advancement trial (16 October 2026).** Dark arena, matching native opponent, 60-second deadline and retry/return flow are implemented behind the class flag.
- [ ] **Owner: balance.** Stat multipliers (`aspd`, `atk`, `hp` in `CD4`) and skill numbers (`SKILLS4`) are provisional. Tune with the new mobs and bosses, then regenerate fixtures.
- [ ] **Agent: browser check.** Nothing has been looked at in a real browser with the flag on: Class Tree row, skill cards, combo bar, icon aliases, the absorb ward and bounce visuals. Do this before the unlock.
- [ ] **Agent: flag-on roster suites.** Several live-page checks will fail once the flag is on (19 → 25 classes, 91 → 109 skills, `JOFF` length, Class Tree rows). Update them deliberately; the go-live checklist in the README lists them.
- [ ] **Owner question: 4th jobs in the Transcendent collection.** The current build keeps the 3rd-job collection at six (the `fourth_job_sim.js` test pins this). Confirm that is intended.

## Gotchas for the next agent

- **Dark-launch discipline.** Anything 4th-job-specific must sit behind `FOURTH_JOBS_LIVE`, or the live fixtures and pins will shift. The only live-code edits are no-op for live skills (`castSkill` hooks check fields only the 4th-job skills have; `absorbSoak` returns the damage untouched with no ward; `katarOnly` gains a class that does not exist live).
- **`combatHash` covers the combat region of `index.html`.** Any edit inside it makes `skill_balance_sim.js` fail until the fixtures are regenerated. Regenerate all three modes, then check the diff is hash-only.
- **The baseline commit `d164bd05` must exist locally.** The balance tools diff against it. If it is missing after an environment reset, run `git fetch --quiet origin d164bd0527cfe335f9c183d0e576800716b7dd26`.
- **`node_modules` is not committed.** Reinstall with `npm install --no-save --package-lock=false jsdom three@0.128.0`. Do not change `package.json`.
- **Test harness pitfalls seen so far:**
  - Node's `deepStrictEqual` fails on arrays from the jsdom realm. Use `JSON.parse(ev(...JSON.stringify...))` (the `probe` helper in `fourth_job_skills_sim.js`).
  - Do not name a local `const fresh` in a probe: it shadows the game's `fresh()` and throws a temporal-dead-zone error.
  - Check counts against the real code, not guesses. Two wrong guesses this session were the live skill count (it is 91) and the Hunting Pounce hit count (2).
- **Roulette strikes and bounces use per-hit damage** (`raw / hits`), so "an extra cut for 60%" means 60% of one cut.
- **Warg Strike's 25% chance** is the owner's example; it is the only roulette number the owner has given.
- **The `skillHit` override in the skill sim** persists in the page for the rest of that run. Each probe resets it, so keep new probes self-contained.

## How to resume

```sh
cd /home/user/Prontera-Grind
git status && git log --oneline -3          # expect 9f4e79d on top, clean tree
npm install --no-save --package-lock=false jsdom three@0.128.0   # only if node_modules is missing
node tools/tests/fourth_job_sim.js          # 20/20 (flag on copy, live-page checks)
node tools/tests/fourth_job_skills_sim.js   # 25/25
node tools/tests/dual_wield_sim.js          # 14/14
for t in tools/tests/*_sim.js tools/tests/*_smoke.js; do node "$t" || echo "FAIL $t"; done
```

Before any push, run the full gate in `docs/TESTING.md`, including the three Python `--check` commands. Do not push, merge or deploy without an explicit instruction.
